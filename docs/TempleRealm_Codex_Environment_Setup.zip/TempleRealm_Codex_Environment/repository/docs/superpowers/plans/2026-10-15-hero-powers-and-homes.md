# Hero powers and homes implementation plan

**Goal:** Continue the current environment chapter into a real mobile superhero exploration sandbox with enterable housing and refined character art.
**Spec:** docs/superpowers/specs/2026-10-15-hero-powers-and-homes-design.md
**Architecture:** Native action controls drive a composed HeroPowers controller through the existing Player; explicit destructible registry separates mutable rocks from protected world. Root owns persistence/UI integration and the checkpoint boundary.

- [x] Prepare original residence shell/furnishings/LOD and serialized geometry tests; actual isolated preview must read as an interior, not a box.
- [x] Implement flight/leap/speed/smash through failing real-physics regression tests, preserving off-state movement and camera.
- [x] Implement native power controls, cancellation and safe mobile layouts; expose only functioning actions.
- [x] Integrate residence approach/steps/solid collision and test actual capsule room-to-room traversal.
- [x] Refine traveler visuals in a separate owned builder, preserving Player/rig APIs and flying pose requirements.
- [x] Finish and verify the Verdant activities/checkpoint milestone before root exposes new powers UI.
- [x] Add schema5 strict hero-state migration, actual destroyed-state restoration and airborne checkpoint/resume.
- [x] Run all existing/new tests and independent review. Record actual15s+ ability/interior/destruction footage and matched environment/mobile views with frozen source hashes; tune visible budgets.
- [x] Run final autonomous cycle/native attempt and honest limit reporting; export code5/name0.5.0.
- [x] Push exact verified source, verify successful GitHub Actions upload, deliver real APK artifact link and updated continuity docs.

Review focus: no flight collision tunneling, leap on canceled touch, stale speed/FOV after overlays, unloaded terrain at extreme speed, destructible collision surviving visual removal, or airborne resume losing flight state. No paid services, signing changes or copied reference imagery.


Final verification: 872 scene assertions/26 suites pass;41 source-matched stills and both 21.0s/26.1s gameplay movies pass. Cycle `20261015T040818Z-3c4414` is PARTIAL with all six core/build stages PASS and native interaction BLOCKED on a fresh, proven stock SystemUI ANR after boot/install/game-ready. No Android assertion was weakened. Successful exact-source `5f987de` GitHub run 38679064762 uploads artifact11946667860 (39.3MB); see AUTONOMOUS_WORKFLOW.md for the verified direct download and TEST_RESULTS.md for limits.
